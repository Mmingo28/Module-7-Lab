import math


def multiply_numbers(myList):
    p = 1
    for x in range(len(myList)):
        p = [n]myList[x]

n = [5,2,7,-1]
multiply_numbers(n)
