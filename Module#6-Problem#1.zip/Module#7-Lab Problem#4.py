import math


def list_of_numbers(myList):
    numbers = []
    for y in myList:
        if y in numbers:
            pass
        else:
            numbers.append(y)
    return numbers
            
    

    

n =  [1, 3, 3, 6, 2, 3, 5]
print(list_of_numbers(n))
