import random
#print range (25,35)

random.randrange(25,35)
myList=[25,35]
for list in range(0,10):
 print(range)
 print(25,35)

