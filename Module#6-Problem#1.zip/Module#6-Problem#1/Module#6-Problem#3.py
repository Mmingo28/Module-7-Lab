import random

#random.randrange(Monday,Friday)
myList=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
#for day in choice(Monday,Friday)

print(random.choice(myList))
