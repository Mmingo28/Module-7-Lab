import math

math.pi
radians_To_Degrees = int(input("How many radians do you have?"))
number_Of_Degrees=radians_To_Degrees*180/math.pi
print(number_Of_Degrees)

