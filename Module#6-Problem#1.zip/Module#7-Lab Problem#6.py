import math

math.pi


import turtle

def drawSquare(t, sz):
    """Get turtle t to draw of sz side"""
    for i in range(4):
        t.forward(sz)
        t.left(90)

wn = turtle.Screen()

alex = turtle.Turtle()
alex.color("Orange")

for different_sizes in range(40,100,20):
    drawSquare(alex, different_sizes)





