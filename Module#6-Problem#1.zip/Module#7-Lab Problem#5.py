import turtle

def drawSquare(t, sz):
    """Get turtle t to draw of sz side"""
    for i in range(4):
        t.forward(sz)
        t.left(90)

wn = turtle.Screen()


alex = turtle.Turtle()
alex.color("blue")

#wn.exitonclick()

for different_sizes in range(10,300,20):
    drawSquare(alex, different_sizes )
    print(different_sizes)
