#import statements
import math


def is_in_range(n):
     

    #r = int(input("give me a range"))
    if n in range(1,10):
        return "Yes"
    #if n not in range(1,10):
    else:
        return "No"
        
print(is_in_range(11))
