#import statements
import math


#define your functions

def areaOfCircle(r):
    A=math.pi*r*r
    return A


#use your functions
r = int(input("give me a radius"))
print(areaOfCircle(r))








